/*		Name:	Abdul Ghaffar Kalhoro
 * 		Registration#	194699
 * 		Class:		BSCS-6C
 * 
 * */

package lab9;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;  
public class DBHandler {
	
	Connection conn = null;
	Statement stmt = null;
void checkConnection() throws SQLException {
	
	
	Statement stmt = null;
	Connection conn = null;
	Connector obj = new Connector();
	conn = obj.method();
	if(conn != null) {
	stmt = 	conn.createStatement();
	this.conn = conn;
	this.stmt = stmt;
	}else 
	{
		System.out.println("can not create connection...!");
	}
}	



	


void getfilecsv() throws IOException, SQLException {
	 PreparedStatement ps = null;
	

	try { 
		String[] array = null;
	        BufferedReader bReader = new BufferedReader(new FileReader("C:\\Users\\agkal\\eclipse-workspace\\testing\\src\\GeoLiteCity.csv"));
	        String line = ""; 
	        int i = 0;
	      
	        while ((line = bReader.readLine()) != null) {
	            try {

	                if (line != null) 
	                {
	                     array = line.split(",+");
	                    for(String result:array)
	                    {
	                       
	                    //	System.out.println(result);
	                    	 //  System.out.println(array[i]);    

	                    	   
	                //  Create preparedStatement here and set them and excute them
	              //  PreparedStatement ps = conn.prepareStatement(sql);
	                // ps.setString(1,str[0]);
	                 //ps.setString(2,str[1]);
	                // ps.setString(3,str[2]);
	                // ps.setString(4,strp[3])
	                // ps.excuteUpdate();
	                // ps. close()
	   //Assuming that your line from file after split will folllow that sequence

	                    }
		             
	                    break;
	                   // System.out.println(line);
	                    
	                 //   System.out.println(array[i]);    
	                   // i++;
	                } 
	            }
	            finally
	            {
	               if (bReader == null) 
	                {
	                    bReader.close();
	                }
	            }
	     
	        
	        }
	        
	        //  Create preparedStatement here and set them and excute them
            String sql = " INSERT INTO geocity(locId,country,region,city,postalCode,latitude,logitude,metroCode,areaCode) VALUES(?,?,?,?,?,?,?,?,?) ";

            ps = conn.prepareStatement(sql);
            
               ps.setString(1,array[0]);
               ps.setString(2,array[1]);
               ps.setString(3,array[2]);
               ps.setString(4,array[3]);
               ps.setString(5,array[4]);
               ps.setString(6,array[5]);
               ps.setString(7,array[6]);
               ps.setString(8,array[7]);
               ps.setString(9,array[8]);
            //   ps.excuteUpdate();
               
               ps.executeUpdate();
               ps. close();
               
	    } catch (FileNotFoundException ex) {
	        ex.printStackTrace();
	    }
	
	
	
	
	
	
	
	
}


public void importData(Connection conn,String filename)
{
    Statement stmt;
    String query;

    try
    {
        stmt = conn.createStatement(
ResultSet.TYPE_SCROLL_SENSITIVE,
ResultSet.CONCUR_UPDATABLE);
       //query = "create database if not exists geoCity; use geoCity; create table if not exists Geo_City_Lite(locId INT AUTO_INCREMENT PRIMARY KEY,country varchar(150),region varchar(150),city varchar(150),postalCode  varchar(150),latitude DECIMAL(12,9),longitude DECIMAL(12,9),metroCode bigint ,areaCode bigint);";
       query = "LOAD DATA INFILE '"+filename+"' INTO TABLE  citiesinfo  FIELDS TERMINATED BY ',' (locId,country,region,city,postalCode,latitude,longitude,metroCode,areaCode)";

        stmt.executeUpdate(query);
             
    }
    catch(Exception e)
    {
        e.printStackTrace();
        stmt = null;
    }
}



public geocity find(String city) throws SQLException {
    String sql = "SELECT latitude, longitude FROM citiesinfo WHERE city = ?";
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    geocity customer = null;


        
        preparedStatement = conn.prepareStatement(sql);
        preparedStatement.setString(1, city);
        resultSet = preparedStatement.executeQuery();
        if (resultSet.next()) {
            customer = new geocity();
            customer.setCity(resultSet.getString("city"));
            customer.setLatitude(resultSet.getInt("latitude"));
            customer.setLogitude(resultSet.getInt("longitude"));
        }
   

    return customer;

}

}