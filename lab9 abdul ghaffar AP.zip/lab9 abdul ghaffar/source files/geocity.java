package lab6;

public class geocity {
	

	private int locId;
	private String country;
	private String lastname;
	private String region;
	private String city;
	private int postalCode;
	private int latitude;
	private int logitude;
	private int metroCode;
	private int areaCode;
	public int getLocId() {
		return locId;
	}
	public void setLocId(int locId) {
		this.locId = locId;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(int postalCode) {
		this.postalCode = postalCode;
	}
	public int getLatitude() {
		return latitude;
	}
	public void setLatitude(int latitude) {
		this.latitude = latitude;
	}
	public int getLogitude() {
		return logitude;
	}
	public void setLogitude(int logitude) {
		this.logitude = logitude;
	}
	public int getMetroCode() {
		return metroCode;
	}
	public void setMetroCode(int metroCode) {
		this.metroCode = metroCode;
	}
	public int getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(int areaCode) {
		this.areaCode = areaCode;
	}
	

}
