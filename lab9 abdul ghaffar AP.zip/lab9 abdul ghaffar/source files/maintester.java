package lab6;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

//import com.opencsv.CSVReader;

public class maintester
{
	public static void main(String[] args) throws IOException, SQLException
	{
		//	readCsv();
		//	readCsvUsingLoad();
	
	
	geocity cityobj;
	DBHandler obj = new DBHandler();

    System.out.println("......Data is inserting into the database....");
	obj.checkConnection();
	   
	//obj.getfilecsv();
    obj.importData(obj.conn, "C:\\ProgramData\\MySQL\\MySQL Server 8.0\\Uploads\\GeoLiteCity.csv");	
	
    System.out.println("......Enter name of the city to find out latitude and the longitude of it: ");
    
    Scanner scanner = new Scanner(System.in);
    String cityName = scanner.nextLine();
	
    cityobj = obj.find(cityName);
    
    System.out.println("The latitude = " + cityobj.getLatitude());
    System.out.println("The longitude = " + cityobj.getLogitude());
    
	}

}
